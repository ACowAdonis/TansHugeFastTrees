package tannyjung.tanshugetrees.procedures;

import tannyjung.tanshugetrees_handcode.world_gen.TreeLocation;

public class OVERLAYGeneratingRegionLoadingProcedure {
	public static double execute() {
		return TreeLocation.generating_region - 1;
	}
}
